package com.example.toastumb;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.toastumb.R;

public class VisualizacionActivity extends AppCompatActivity {

    private TextView textViewNombre;
    private TextView textViewApellido;
    private TextView textViewEdad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizacion);

        textViewNombre = findViewById(R.id.textViewNombre);
        textViewApellido = findViewById(R.id.textViewApellido);
        textViewEdad = findViewById(R.id.textViewEdad);

        Intent intent = getIntent();
        String nombre = intent.getStringExtra("nombre");
        String apellido = intent.getStringExtra("apellido");
        int edad = intent.getIntExtra("edad", 0);

        textViewNombre.setText("Nombre: " + nombre);
        textViewApellido.setText("Apellido: " + apellido);
        textViewEdad.setText("Edad: " + String.valueOf(edad));
    }
}
