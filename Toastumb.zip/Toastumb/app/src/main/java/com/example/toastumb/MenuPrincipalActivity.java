package com.example.toastumb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MenuPrincipalActivity extends AppCompatActivity {

    private Button btnPaginaPrincipal;
    private Button btnBuscarPagina;
    private Button btnFormulario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        btnPaginaPrincipal = findViewById(R.id.btnPaginaPrincipal);
        btnBuscarPagina = findViewById(R.id.btnBuscarPagina);
        btnFormulario = findViewById(R.id.btnFormulario);

        btnPaginaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción al hacer clic en el botón de la página principal
                abrirPaginaPrincipal();
            }
        });

        btnBuscarPagina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción al hacer clic en el botón de buscar página
                abrirBuscarPagina();
            }
        });

        btnFormulario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción al hacer clic en el botón del formulario
                abrirFormulario();
            }
        });
    }

    private void abrirPaginaPrincipal() {
        // Abrir la página principal (https://umb.instructure.com/)
        Intent intent = new Intent(MenuPrincipalActivity.this, WebViewActivity.class);
        intent.putExtra("url", "https://umb.instructure.com/");
        startActivity(intent);
    }

    private void abrirBuscarPagina() {
        // Abrir la actividad de buscar página
        Intent intent = new Intent(MenuPrincipalActivity.this, BuscarPaginaActivity.class);
        startActivity(intent);
    }

    private void abrirFormulario() {
        // Abrir la actividad de formulario
        Intent intent = new Intent(MenuPrincipalActivity.this, FormularioActivity.class);
        startActivity(intent);
    }
}

